package com.example.demo.controllers;

import com.example.demo.dto.AuthDtos.MessageResponse;
import com.example.demo.dto.AuthDtos.PhotoResponse;
import com.example.demo.dto.AuthDtos.PlayerProfileUpdateRequest;
import com.example.demo.dto.TeamManagementDtos.PlayerTeamViewDto;
import com.example.demo.services.PlayerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/api/player")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@PreAuthorize("hasRole('PLAYER')")
public class PlayerController {

    private final PlayerService playerService;

    /**
     * GET /api/player/team/{playerId}
     * Returns full team view: team info + captain card + player roster.
     */
    @GetMapping("/team/{playerId}")
    public ResponseEntity<PlayerTeamViewDto> getTeamView(@PathVariable String playerId) {
        return ResponseEntity.ok(playerService.getTeamView(playerId));
    }

    /**
     * PUT /api/player/profile/{playerId}
     * Update player's fullName / email / password (currentPassword required).
     */
    @PutMapping("/profile/{playerId}")
    public ResponseEntity<MessageResponse> updateProfile(
            @PathVariable String playerId,
            @RequestBody PlayerProfileUpdateRequest request) {
        playerService.updateProfile(playerId, request);
        return ResponseEntity.ok(new MessageResponse("Profile updated successfully."));
    }

    /**
     * POST /api/player/profile/{playerId}/photo
     * Upload / replace the player's avatar photo.
     */
    @PostMapping(value = "/profile/{playerId}/photo", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PhotoResponse> uploadPhoto(
            @PathVariable String playerId,
            @RequestParam("file") MultipartFile file) {
        try {
            String dataUrl = playerService.uploadPhoto(playerId, file);
            return ResponseEntity.ok(new PhotoResponse("Photo updated successfully.", dataUrl));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new PhotoResponse(e.getMessage(), null));
        }
    }

    /**
     * DELETE /api/player/profile/{playerId}/photo
     * Remove the player's avatar photo.
     */
    @DeleteMapping("/profile/{playerId}/photo")
    public ResponseEntity<MessageResponse> deletePhoto(@PathVariable String playerId) {
        playerService.deletePhoto(playerId);
        return ResponseEntity.ok(new MessageResponse("Photo removed successfully."));
    }

    /**
     * GET /api/player/profile/{playerId}/photo
     * Returns the current photoUrl (data-url string or empty string).
     */
    @GetMapping("/profile/{playerId}/photo")
    public ResponseEntity<Map<String, String>> getPhoto(@PathVariable String playerId) {
        String url = playerService.getPhotoUrl(playerId);
        return ResponseEntity.ok(Map.of("photoUrl", url != null ? url : ""));
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<MessageResponse> handleError(RuntimeException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new MessageResponse(ex.getMessage()));
    }
}
