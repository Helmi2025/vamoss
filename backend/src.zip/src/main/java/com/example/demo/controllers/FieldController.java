package com.example.demo.controllers;

import com.example.demo.dto.FieldDto;
import com.example.demo.services.FieldService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/fields")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FieldController {

    private final FieldService fieldService;

    /**
     * GET /api/fields
     * Returns all fields. Optional filters: ?sportId=... or ?available=true/false
     */
    @GetMapping
    public ResponseEntity<List<FieldDto>> getAll(
            @RequestParam(required = false) String sportId,
            @RequestParam(required = false) Boolean available) {

        if (Boolean.TRUE.equals(available) || (available == null && sportId == null)) {
            // No filters → return everything
            if (sportId == null && available == null) {
                return ResponseEntity.ok(fieldService.getAllFields());
            }
            // Available filter with optional sport
            return ResponseEntity.ok(fieldService.getAvailableFields(sportId));
        }

        // Sport filter only
        if (sportId != null) {
            return ResponseEntity.ok(fieldService.getFieldsBySport(sportId));
        }

        return ResponseEntity.ok(fieldService.getAllFields());
    }

    /**
     * GET /api/fields/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<FieldDto> getById(@PathVariable String id) {
        return ResponseEntity.ok(fieldService.getFieldById(id));
    }

    /**
     * POST /api/fields
     * Admin only — create a field linked to a sport.
     * Body: { "name": "Field A", "sportId": "..." }
     */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<FieldDto> create(@RequestBody Map<String, String> body) {
        String name    = body.get("name");
        String sportId = body.get("sportId");

        if (name == null || name.isBlank())    throw new RuntimeException("Field name is required");
        if (sportId == null || sportId.isBlank()) throw new RuntimeException("sportId is required");

        return ResponseEntity.ok(fieldService.createField(name, sportId));
    }

    /**
     * PUT /api/fields/{id}
     * Admin only — update name, sportId, or availability.
     * Body (all optional): { "name": "...", "sportId": "...", "available": true }
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<FieldDto> update(
            @PathVariable String id,
            @RequestBody Map<String, Object> body) {

        String  name      = (String)  body.get("name");
        String  sportId   = (String)  body.get("sportId");
        Boolean available = body.get("available") instanceof Boolean
                ? (Boolean) body.get("available") : null;

        return ResponseEntity.ok(fieldService.updateField(id, name, sportId, available));
    }

    /**
     * PATCH /api/fields/{id}/availability
     * Admin only — toggle availability quickly.
     * Body: { "available": true }
     */
    @PatchMapping("/{id}/availability")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<FieldDto> setAvailability(
            @PathVariable String id,
            @RequestBody Map<String, Boolean> body) {

        Boolean available = body.get("available");
        if (available == null) throw new RuntimeException("'available' field is required");
        return ResponseEntity.ok(fieldService.setAvailability(id, available));
    }

    /**
     * DELETE /api/fields/{id}
     * Admin only.
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        fieldService.deleteField(id);
        return ResponseEntity.noContent().build();
    }
}
